/* * PROJECT:     AG~3 NEURO-PATH - Primary sensory fusion core
 * DESCRIPTION: Multi-sensor fusion engine managing LCD HUD telemetry, hardware failure 
 * diagnostics, and motion-gated safety indicators.
 * VERSION:     12.3
 */

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <ESP32Servo.h>

// --- Pin Allocations ---
#define TRIG_PIN     12
#define ECHO_PIN     13
#define BUZZER_PIN    4  // Active warning buzzer (Wired in parallel with Red LED)
#define GREEN_LED     2  // System clear indicator
#define SERVO_PIN    14

// --- Peripheral Instances ---
LiquidCrystal_I2C lcd(0x27, 16, 2);
Servo radarServo;

// --- Global Tracking Matrices ---
long pulseDuration;
int laserDistanceCm;
int visionTargetDistance = 999; 
int currentServoAngle = 90;
bool scanningIncrement = true;

void setup() {
  Serial.begin(115200);
  
  // Configure Alert I/O Matrix
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  
  // Initialize Parallel Warning Array (Ensure quiet boot)
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(GREEN_LED, LOW);
  
  // Wake Peripherals
  radarServo.attach(SERVO_PIN);
  lcd.init();
  lcd.backlight();
  
  // Execution Boot Splash Terminal
  lcd.setCursor(0, 0);
  lcd.print("   NEURO-PATH   ");
  lcd.setCursor(0, 1);
  lcd.print(" BLINDSPOT SYS  ");
  
  // Sound parallel boot indicator check
  digitalWrite(BUZZER_PIN, HIGH);
  delay(300);
  digitalWrite(BUZZER_PIN, LOW);
  delay(1000);
  
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("SYSTEM BOOT...");
  delay(800);
}

void loop() {
  // 1. Dynamic Radar Scanning Sweep Pipeline
  radarServo.write(currentServoAngle);
  
  if (scanningIncrement) {
    currentServoAngle += 2;
    if (currentServoAngle >= 150) scanningIncrement = false;
  } else {
    currentServoAngle -= 2;
    if (currentServoAngle <= 30) scanningIncrement = true;
  }
  
  // 2. Ultrasonic Time-of-Flight Ranging Pipeline
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  
  pulseDuration = pulseIn(ECHO_PIN, HIGH, 30000); // 30ms timeout safeguard
  
  if (pulseDuration == 0) {
    laserDistanceCm = 999; 
  } else {
    laserDistanceCm = pulseDuration * 0.0343 / 2;
  }
  
  // 3. Read Inbound Binary Computer Vision Strings
  if (Serial.available() > 0) {
    String payload = Serial.readStringUntil('\n');
    if (payload.startsWith("DIST:")) {
      visionTargetDistance = payload.substring(5).toInt();
    }
  }
  
  // 4. Motion-Gated Sensor Fusion Threat Matrix Evaluator
  int evaluatedThreatZone = min(laserDistanceCm, visionTargetDistance);
  
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("U:");
  lcd.print(visionTargetDistance);
  lcd.print(" L:");
  lcd.print(laserDistanceCm);
  lcd.print(" cm");
  
  lcd.setCursor(0, 1);
  if (evaluatedThreatZone > 50) {
    lcd.print("STATUS: CLEAR ");
    digitalWrite(GREEN_LED, HIGH);
    digitalWrite(BUZZER_PIN, LOW);
  } 
  else if (evaluatedThreatZone <= 50 && evaluatedThreatZone > 20) {
    lcd.print("CAUTION: SLOW ");
    digitalWrite(GREEN_LED, LOW);
    
    digitalWrite(BUZZER_PIN, HIGH);
    delay(50);
    digitalWrite(BUZZER_PIN, LOW);
  } 
  else {
    lcd.print("CAUTION: ALERT!");
    digitalWrite(GREEN_LED, LOW);
    digitalWrite(BUZZER_PIN, HIGH); 
  }
  
  delay(40); 
}